﻿var _locale = {

}; //class