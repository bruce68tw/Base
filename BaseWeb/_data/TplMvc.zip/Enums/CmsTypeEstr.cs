﻿namespace $safeprojectname$.Enums
{
    public static class CmsTypeEstr
    {
        public const string Msg = "Msg";    //最新消息
        public const string Card = "Card";  //電子賀卡
    }
}